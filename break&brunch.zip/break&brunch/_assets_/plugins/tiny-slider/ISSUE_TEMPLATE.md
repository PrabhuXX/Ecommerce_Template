__Issue description__:  

__Demo link/slider setting__:   

_Tiny-slider version_:   
_Browser name && version_:  
_OS name && version_:   